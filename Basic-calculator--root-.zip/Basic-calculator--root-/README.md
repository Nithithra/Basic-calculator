# Basic Calculator

A simple calculator using HTML, CSS, and JavaScript. It supports:
- Addition
- Subtraction
- Multiplication
- Division

## Features
- Clear button
- Decimal input
- Responsive layout

## How to Use
1. Clone or download the repo
2. Open `index.html` in a browser

## Screenshot
![Calculator Screenshot](screenshot.png)
